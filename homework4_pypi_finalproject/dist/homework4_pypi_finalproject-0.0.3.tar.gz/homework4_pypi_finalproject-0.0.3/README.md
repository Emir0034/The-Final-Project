You need a file called orcl.csv
When you execute the code, it will create two files that name's orcl-sma.csv and orcl-rsi.csv
For install the this Python package use pip install homework4_pypi_finalproject==0.0.3 command