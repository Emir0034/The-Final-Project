You need a file called orcl.csv

When you execute the code, it will create two files that name's orcl-sma.csv and orcl-rsi.csv

For install the this Python package use the pip command above.